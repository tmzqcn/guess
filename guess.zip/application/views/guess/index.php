<?php
    echo 'guess index';
    var_dump($this->session->roles);