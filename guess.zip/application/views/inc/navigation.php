<nav class="navbar navbar-default navbar-fixed-top">
<?php
/**
 * Created by PhpStorm.
 * User: lulu
 * Date: 2016/6/4
 * Time: 16:08
 */

echo'i am navigation .';


?>
</nav>