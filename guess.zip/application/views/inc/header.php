<!DOCTYPE html>
<html lang="cn">
<head>
    <meta charset="utf-8">

    <title>guess</title>


    <!-- 新 Bootstrap 核心 CSS 文件 -->
    <link rel="stylesheet" href="<?php echo base_url('asset/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('asset/css/style.css'); ?>">

    <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
    <script src="<?php echo base_url('asset/js/jquery.min.js');  ?>"></script>
    <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
    <script src="<?php echo base_url('asset/js/bootstrap.min.js');  ?>"></script>




</head>
<body>
    <div class="container">
<?php
    require_once('navigation.php');
?>